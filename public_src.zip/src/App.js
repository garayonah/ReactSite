import './App.css';

function App() {
  return (
    <div id="App">
      <header>
        <div id='namePlate' className='side section'>
          <h1>Name Here</h1>
          <h2>Profession Here</h2>
        </div>
        <div id='navigation' className='body section'>
          <a href='#about'>About</a>
          <a href='#experience'>Experience</a>
        </div>
      </header>
      <div id='main'>
        <div id='main-side' className='side section'>
          <div className='subsection'>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
          </div>
          <a className='subsection link' href='mailto:email@email.com'>email@email.com</a>
          <a className='subsection link' href='linkedin.com'>LinkedIn</a>
        </div>
        <div id='experience' className='body section'>
          <div className='subsection' >
            <a href='#work' >Work</a>
            <a href='#education' >Education</a>
            <a href='#skills' >Skills</a>
          </div>

          <div id="work">
            <div className='subsection'>
              <div className='jobDetails' >
                <h4>Job Title</h4>
                <div>Current Employer LTD</div>
                <div>March 2021 - Present</div>
                <div>City, Region, Country</div>
              </div>

              <div className='jobDescription'>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
              </div>
            </div>
            
            <div className='subsection'>
              <div className='jobDetails' >
                <h4>Job Title</h4>
                <div>Past Employer LTD</div>
                <div>January 2019 - February 2021</div>
                <div>City, Region, Country</div>
              </div>

              <div className='jobDescription'>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
              </div>
            </div>

          </div>

          <div id="education">

          </div>

        </div>
      </div>
    </div>
  );
}

export default App;
